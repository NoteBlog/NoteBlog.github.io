<div class="post istop">
	<h2 class="post-title">[置顶]<a href="{$article.Url}">{$article.Title}</a></h2>
</div>