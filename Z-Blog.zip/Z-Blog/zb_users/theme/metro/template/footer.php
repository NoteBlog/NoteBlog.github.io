<div id="footer">
  <div class="copyright">
    <p>Powered By {$zblogphphtml}</p>
    <p>{$copyright}</p>
  </div>
  <div id="goTopBtn">
    <a onclick="pageScroll()"><span>返回顶部</span></a>
  </div>
  <div class="clear"></div>
</div>
{$footer}
</body>
</html>